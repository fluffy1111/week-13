import React from "react";
import { ReactDOM } from "react-dom";
import Thing from './thing';

let element = React.createElement('h1', {}, 'this is React!')
ReactDOM.render(element, document.getElementById('app'));

let Thing = new Thing('rock', 'sedement');
Thing.display('thing');