import $ from 'jquery';
export default class Thing {
    constructor(name, type) {
        this.name = name;
        this.type = type;
    }

    display(elementId) {
        $('#${elementId}').text('${this.name} ${this.type}');
    }
}